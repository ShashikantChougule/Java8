package com.training.model;

public enum DishType {
	MEAT, FISH, OTHER
}
